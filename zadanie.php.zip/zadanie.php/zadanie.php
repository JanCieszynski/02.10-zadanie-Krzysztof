<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <h2>Logowanie</h2>
    <form action="dodaj.php" method="post" target="blank">
      <label for="imie">Imie:</label><br />
      <input type="text" id="Imie" name="Imie" /><br />
      <label for="nazwisko">Nazwisko</label><br />
      <input type="text" id="Nazwisko" name="Nazwisko" /><br />
      <input type="submit" value="Dodaj" />
      <input type="submit" value="Resetuj" />
    </form>
</body>
</html>